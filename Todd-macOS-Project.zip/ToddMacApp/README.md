# Todd for macOS 🐾

A native macOS wrapper for the Todd website. The website is bundled inside the app, so the main experience works offline.

## Compatibility
- macOS 12 Monterey or newer
- Built as a native SwiftUI + WebKit app
- Birthday countdown is fixed to February 7; visitors cannot change it

## Build the DMG without owning a Mac
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Choose **Build Todd for macOS (DMG)**.
4. Press **Run workflow** (or push to `main`).
5. When it finishes, open the run and download the **Todd-macOS-DMG** artifact.
6. Open `Todd-macOS.dmg` on your Mac, then drag Todd into Applications.

## Notes
- This workflow creates an unsigned DMG/app for personal testing. It is not Developer ID signed or notarized, so macOS may show a security warning when first opening it.
- The website's local features, including the birthday countdown, game score, and bark sound, are included in the app.
- Photos added to the museum are currently kept in the app's WebKit session and are not uploaded to a server.
