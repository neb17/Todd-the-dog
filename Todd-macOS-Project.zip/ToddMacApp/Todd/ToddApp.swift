import SwiftUI
import WebKit

@main
struct ToddApp: App {
    var body: some Scene {
        WindowGroup {
            ToddWebView()
                .frame(minWidth: 820, minHeight: 640)
        }
        .windowStyle(.titleBar)
    }
}

struct ToddWebView: NSViewRepresentable {
    func makeNSView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.allowsBackForwardNavigationGestures = true
        webView.setValue(false, forKey: "drawsBackground")

        if let htmlURL = Bundle.main.url(forResource: "Todd-Website", withExtension: "html") {
            webView.loadFileURL(htmlURL, allowingReadAccessTo: htmlURL.deletingLastPathComponent())
        } else {
            let html = "<html><body style='font-family:-apple-system;padding:40px'><h1>🐾 Todd</h1><p>The Todd website could not be found in the app bundle.</p></body></html>"
            webView.loadHTMLString(html, baseURL: nil)
        }
        return webView
    }

    func updateNSView(_ nsView: WKWebView, context: Context) {}
}
